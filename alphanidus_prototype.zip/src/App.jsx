import React from 'react'
import './style.css'

export default function App() {
  return (
    <div className="container">
      <h1>🚀 Alphanidus Prototype</h1>
      <p>Interfaz 3D inicial para el proyecto.</p>
    </div>
  )
}
